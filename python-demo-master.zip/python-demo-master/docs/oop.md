# Basic 面向对象

## Project-1
* 管理员 ：
    * 管理员注册登录（账号、密码）
    * 创建老师（姓名、性别、年龄、资产）
    * 创建课程（课程名称、上课时间、课时费、任课老师）
    * 查看教师
    * 查看课程
* 学生：
    * 学生注册登录（账号，密码，选课列表）
    * 选课
    * 上课签到
    * 查看已选课程

 参考：[https://github.com/mgss/course-management-system](https://github.com/mgss/course-management-system)
