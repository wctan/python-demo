# Basic 基础练习

## Demo-1

* 冒泡排序
* 利用冒泡排序对列表进行排序

 参考Demo：[链接](https://github.com/mgss/python-demo/blob/master/example/algo/demo1.py)

## Demo-2

* 递归
* 利用递归计算斐波那契数列

 参考Demo：[链接](https://github.com/mgss/python-demo/blob/master/example/algo/demo2.py)
